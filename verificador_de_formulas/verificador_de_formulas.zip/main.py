from lexer import Lexer
from analisys import Parser

text_input = """1. A, C def A
2. ~A def ~ 1
3. B def A
4. ~A -> B def -> 2-3
5. A & C def & 1-1
6. (~A -> B) | (A & C) def | 4-5
7. (A & C) | ~A def | 5-2
8. ~C  def ~ 1
9. (~A -> ~C) def -> 2-8
10. (~A -> ~C) & ((A & C) | ~A) def & 9-7
11. ((~A -> ~C) & ((A & C) | ~A)) <-> ((~A -> B) | (A & C)) def <-> 10-6
"""

lexer = Lexer().get_lexer()
tokens = lexer.lex(text_input)

pg = Parser(state=text_input)
pg.parse()
parser = pg.get_parser()
parser.parse(tokens)